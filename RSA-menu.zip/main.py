
encrypted_message = ''
encrypted_message2 = ''

LUT_encryption = dict()
LUT_decryption = dict()

#while loop that controls the entire program goes here
program_on = True 
while program_on: 


  option = input('Type "1" to encrypt a message, type "2" to decrypt')
  if option == '1':
      ## encryption function goes here
      n = input('Please enter the n value (P * Q):')
      e = input('Please enter the e value (smallest co-prime number between your P and Q values):')
      message = input('Please enter the message you wish to encrypt:')
      for t in message:
          if t in LUT_encryption:
              encrypted_message += LUT_encryption[t]
              print('Encrypted message: ',encrypted_message)
            
          else:
              numerize = ord(t)
              encrypt = pow(numerize, e, n)
              denumerize = chr(encrypt)
              encrypted_message += denumerize
              LUT_encryption[t] = denumerize
                
      print('Encrypted message: ',encrypted_message)
        
  
  elif option == '2': 
    ## decryption function goes here
    d = input('Please enter d value:')
    n = input('Please enter n value (P * Q):')
    decrypt_message = input('Please enter the message you wish to decrypt:')
    
    for t in encrypted_message:
     if t in LUT_encryption:
      encrypted_message == LUT_encryption[t]

     else: 
          numerize and [t]
          decrypt = pow(numerize, e, n)
          encrypted_message += denumerize
          LUT_encryption[t]
    print ('Decrypted message: ',encrypted_message2)
  
  ##option to exit goes here
  stop = input('Press "s" to stop, press "c" to continue')
  if stop == 's':
    program_on = False
    print ('Restart the program to use again')
  